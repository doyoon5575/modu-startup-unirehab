"""UniRehab core package."""
